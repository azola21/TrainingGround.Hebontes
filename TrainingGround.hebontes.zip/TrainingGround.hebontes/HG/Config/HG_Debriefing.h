/*
    Author - HoverGuy
    © All Fucks Reserved
	Website - http://www.sunrise-production.com
*/

class NotWhitelisted
{
	title = "$STR_HG_DEBRIEF_NL_TITLE";
	subtitle = "";
	description = "$STR_HG_DEBRIEF_NL_DESC";
	pictureBackground = "";
	picture = "\A3\ui_f\data\map\MapControl\taskiconfailed_ca.paa";
	pictureColor[] = {0,0.3,0.6,1};
};
