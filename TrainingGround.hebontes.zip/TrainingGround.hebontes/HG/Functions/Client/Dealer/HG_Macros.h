#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
	Website - http://www.sunrise-production.com
*/

#define HG_DEALER_DISP            findDisplay HG_DEALER_IDD
#define HG_DEALER_PRICE           (HG_DEALER_DISP displayCtrl HG_DEALER_PRICE_IDC)
#define HG_DEALER_V_LIST          (HG_DEALER_DISP displayCtrl HG_DEALER_V_LIST_IDC)
#define HG_DEALER_D_LIST          (HG_DEALER_DISP displayCtrl HG_DEALER_D_LIST_IDC)
#define HG_DEALER_REFRESH_BTN     (HG_DEALER_DISP displayCtrl HG_DEALER_REFRESH_BTN_IDC)
#define HG_DEALER_SELL_BTN        (HG_DEALER_DISP displayCtrl HG_DEALER_SELL_BTN_IDC)
