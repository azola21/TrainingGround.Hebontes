#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
	Website - http://www.sunrise-production.com
*/

#define HG_ITEMS_SHOP_DISP	      findDisplay HG_ITEMS_SHOP_IDD
#define HG_ITEMS_ITEM_LIST	      (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_ITEM_LIST_IDC)
#define HG_ITEMS_ITEM_TEXT	      (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_ITEM_TEXT_IDC)
#define HG_ITEMS_ITEM_PICTURE	  (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_ITEM_PICTURE_IDC)
#define HG_ITEMS_ITEM_SWITCH	  (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_ITEM_SWITCH_IDC)
#define HG_ITEMS_BUY			  (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_BUY_IDC)
#define HG_ITEMS_MC               (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_MC_IDC)
#define HG_ITEMS_AMOUNT           (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_AMOUNT_IDC)
#define HG_ITEMS_ADD              (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_ADD_IDC)
#define HG_ITEMS_SUB              (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_SUB_IDC)
#define HG_ITEMS_TOTAL            (HG_ITEMS_SHOP_DISP displayCtrl HG_ITEMS_TOTAL_IDC)
