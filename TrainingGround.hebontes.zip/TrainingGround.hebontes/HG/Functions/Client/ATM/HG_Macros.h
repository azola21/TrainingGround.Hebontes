#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
    Website - http://www.sunrise-production.com
*/

#define HG_ATM_DISP               findDisplay HG_ATM_IDD
#define HG_ATM_ACC_TEXT           (HG_ATM_DISP displayCtrl HG_ATM_ACC_TEXT_IDC)
#define HG_ATM_CASH_TEXT          (HG_ATM_DISP displayCtrl HG_ATM_CASH_TEXT_IDC)
#define HG_ATM_ACC_EDIT           (HG_ATM_DISP displayCtrl HG_ATM_ACC_EDIT_IDC)
#define HG_ATM_CASH_EDIT          (HG_ATM_DISP displayCtrl HG_ATM_CASH_EDIT_IDC)
#define HG_ATM_PLAYERS_COMBO      (HG_ATM_DISP displayCtrl HG_ATM_PLAYERS_COMBO_IDC)
#define HG_ATM_TRANSFER_BTN       (HG_ATM_DISP displayCtrl HG_ATM_TRANSFER_BTN_IDC)
#define HG_ATM_REFRESH_BTN        (HG_ATM_DISP displayCtrl HG_ATM_REFRESH_BTN_IDC)
