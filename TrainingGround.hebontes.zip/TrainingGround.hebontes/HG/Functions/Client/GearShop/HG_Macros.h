#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
	Website - http://www.sunrise-production.com
*/

#define HG_GEAR_SHOP_DISP	  findDisplay HG_GEAR_SHOP_IDD
#define HG_GEAR_TOTAL         (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_TOTAL_IDC)
#define HG_GEAR_SWITCH	      (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_SWITCH_IDC)
#define HG_GEAR_LIST		  (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_LIST_IDC)
#define HG_GEAR_RESET         (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_RESET_IDC)
#define HG_GEAR_BUY           (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_BUY_IDC)
#define HG_GEAR_MC            (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_MC_IDC)
#define HG_GEAR_SLIDER        (HG_GEAR_SHOP_DISP displayCtrl HG_GEAR_SLIDER_IDC)
