#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
    Website - http://www.sunrise-production.com
*/

#define HG_TAGS_DISP         (uiNamespace getVariable ["HG_Tags",displayNull])
#define HG_TAGS_TEXT         (HG_TAGS_DISP displayCtrl HG_TAGS_TEXT_IDC)
