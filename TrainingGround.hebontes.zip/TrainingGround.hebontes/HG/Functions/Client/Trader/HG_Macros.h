#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
	Website - http://www.sunrise-production.com
*/

#define HG_TRADER_DISP          findDisplay HG_TRADER_IDD
#define HG_TRADER_QTY           (HG_TRADER_DISP displayCtrl HG_TRADER_QTY_IDC)
#define HG_TRADER_PRICE         (HG_TRADER_DISP displayCtrl HG_TRADER_PRICE_IDC)
#define HG_TRADER_TOTAL         (HG_TRADER_DISP displayCtrl HG_TRADER_TOTAL_IDC)
#define HG_TRADER_TREE          (HG_TRADER_DISP displayCtrl HG_TRADER_TREE_IDC)
#define HG_TRADER_LIST          (HG_TRADER_DISP displayCtrl HG_TRADER_LIST_IDC)
#define HG_TRADER_SUB_BTN       (HG_TRADER_DISP displayCtrl HG_TRADER_SUB_BTN_IDC)
#define HG_TRADER_ADD_BTN       (HG_TRADER_DISP displayCtrl HG_TRADER_ADD_BTN_IDC)
#define HG_TRADER_SELL_BTN      (HG_TRADER_DISP displayCtrl HG_TRADER_SELL_BTN_IDC)
