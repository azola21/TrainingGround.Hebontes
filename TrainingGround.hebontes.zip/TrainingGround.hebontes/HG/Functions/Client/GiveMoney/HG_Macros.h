#include "..\..\..\UI\HG_IDCS.h"
/*
    Author - HoverGuy
    © All Fucks Reserved
	Website - http://www.sunrise-production.com
*/

#define HG_GM_DISP                findDisplay HG_GM_IDD
#define HG_GM_EDIT                (HG_GM_DISP displayCtrl HG_GM_EDIT_IDC)
