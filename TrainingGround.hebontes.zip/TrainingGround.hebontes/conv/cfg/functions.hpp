class IP
{
	class conv
	{
		class addConversation
		{
			file = "conv\fnc\addConversation.sqf";
		};
		class ambientChatter
		{
			file = "conv\fnc\ambientChatter.sqf";
		};
		class ambientChatterKB
		{
			file = "conv\fnc\ambientChatterKB.sqf";
		};
		class closeConversation
		{
			file = "conv\fnc\closeConversation.sqf";
		};
		class openConversation
		{
			file = "conv\fnc\openConversation.sqf";
		};
		class removeConversation
		{
			file = "conv\fnc\removeConversation.sqf";
		};
		class selectResponse
		{
			file = "conv\fnc\selectResponse.sqf";
		};
		class simpleConversation
		{
			file = "conv\fnc\simpleConversation.sqf";
		};
		class simpleConversationKB
		{
			file = "conv\fnc\simpleConversationKB.sqf";
		};
		class simpleSentence
		{
			file = "conv\fnc\simpleSentence.sqf";
		};
		class simpleSentenceKB
		{
			file = "conv\fnc\simpleSentenceKB.sqf";
		};
	};
};