#ifdef SAF_DEF
	#include "cfg\common_saf.cpp"
#endif

#ifdef SAF_FNCS
	#include "cfg\cfgFunctions.cpp"
#endif