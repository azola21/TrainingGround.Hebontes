#define SAF_MISSION_SETTINGS(s1,s2) missionConfigFile >> #s2
#define SAF_MISSION_SET(s1) saf_mission_setting_##s1
