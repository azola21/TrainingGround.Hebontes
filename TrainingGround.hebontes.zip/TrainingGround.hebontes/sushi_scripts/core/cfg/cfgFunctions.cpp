	
	class core
	{
		file = "sushi_scripts\core\fncs";
		class preInit { preInit = 1; };
		class showStatus {};
	};


