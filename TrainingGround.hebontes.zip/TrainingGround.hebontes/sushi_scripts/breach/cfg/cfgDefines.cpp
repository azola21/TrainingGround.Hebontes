#include "..\..\core\cfg\cfgDefines.cpp"
#define SAF_PLUG_BREACH(s1) missionConfigFile >> "BREACH" >> #s1
#define SAF_PLUG_DIARY "saf_diary_breach"